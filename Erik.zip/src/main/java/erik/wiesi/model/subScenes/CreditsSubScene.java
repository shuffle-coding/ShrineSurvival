package erik.wiesi.model.subScenes;

import erik.wiesi.model.ShrineSurvivalSubScene;

public class CreditsSubScene extends ShrineSurvivalSubScene {

    // TODO: mentioning KENNEY.NL for GAME ASSESTS
}

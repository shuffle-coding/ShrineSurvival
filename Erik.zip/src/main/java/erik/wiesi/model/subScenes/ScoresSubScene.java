package erik.wiesi.model.subScenes;

import erik.wiesi.model.ShrineSurvivalSubScene;

public class ScoresSubScene  extends ShrineSurvivalSubScene {
}

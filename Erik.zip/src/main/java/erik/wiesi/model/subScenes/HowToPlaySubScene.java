package erik.wiesi.model.subScenes;

import erik.wiesi.model.ShrineSurvivalSubScene;

public class HowToPlaySubScene extends ShrineSurvivalSubScene {
}

package erik.wiesi.model.subScenes;

import erik.wiesi.model.ShrineSurvivalSubScene;

public class SettingsSubScene extends ShrineSurvivalSubScene {
}

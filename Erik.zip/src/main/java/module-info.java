module erik.wiesi {
    requires javafx.controls;
    requires java.desktop;
    exports erik.wiesi.main;
}